package com.example.quizapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class QuizActivity : AppCompatActivity() {

    private var questionList: ArrayList<Question>? = null
    private var currentPosition: Int = 1
    private var selectedOption: Int = 0
    private var correctAnswers: Int = 0

    private lateinit var tvQuestion: TextView
    private lateinit var tvOptionOne: TextView
    private lateinit var tvOptionTwo: TextView
    private lateinit var tvOptionThree: TextView
    private lateinit var tvOptionFour: TextView
    private lateinit var btnNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        // View элементтерін байланыстыру
        tvQuestion = findViewById(R.id.tv_question)
        tvOptionOne = findViewById(R.id.tv_option_one)
        tvOptionTwo = findViewById(R.id.tv_option_two)
        tvOptionThree = findViewById(R.id.tv_option_three)
        tvOptionFour = findViewById(R.id.tv_option_four)
        btnNext = findViewById(R.id.btn_next)

        questionList = getQuestions()
        setQuestion()

        // Опцияларға басу
        tvOptionOne.setOnClickListener { selectOption(1) }
        tvOptionTwo.setOnClickListener { selectOption(2) }
        tvOptionThree.setOnClickListener { selectOption(3) }
        tvOptionFour.setOnClickListener { selectOption(4) }

        // Келесі батырмасы
        btnNext.setOnClickListener {
            if (selectedOption == 0) {
                // Егер жауап таңдалмаса — ештеңе істемейміз
                return@setOnClickListener
            }

            val question = questionList!![currentPosition - 1]

            // Дұрыс па, қате ме тексеру
            if (selectedOption == question.correctAnswer) {
                correctAnswers++
            }

            // Соңғы сұрақ па?
            if (currentPosition < questionList!!.size) {
                currentPosition++
                selectedOption = 0
                setQuestion()
            } else {
                // Барлық сұрақ аяқталды → ResultActivity-ге өту
                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("user_name", "Қатысушы")
                intent.putExtra("correct_answers", correctAnswers)
                intent.putExtra("total_questions", questionList!!.size)
                startActivity(intent)
                finish()
            }
        }
    }

    private fun selectOption(option: Int) {
        selectedOption = option
        resetOptionColors()

        when (option) {
            1 -> tvOptionOne.setBackgroundColor(Color.LTGRAY)
            2 -> tvOptionTwo.setBackgroundColor(Color.LTGRAY)
            3 -> tvOptionThree.setBackgroundColor(Color.LTGRAY)
            4 -> tvOptionFour.setBackgroundColor(Color.LTGRAY)
        }
    }

    private fun resetOptionColors() {
        tvOptionOne.setBackgroundColor(Color.TRANSPARENT)
        tvOptionTwo.setBackgroundColor(Color.TRANSPARENT)
        tvOptionThree.setBackgroundColor(Color.TRANSPARENT)
        tvOptionFour.setBackgroundColor(Color.TRANSPARENT)
    }

    private fun setQuestion() {
        val question = questionList!![currentPosition - 1]

        tvQuestion.text = question.question
        tvOptionOne.text = question.optionOne
        tvOptionTwo.text = question.optionTwo
        tvOptionThree.text = question.optionThree
        tvOptionFour.text = question.optionFour

        resetOptionColors()
    }

    private fun getQuestions(): ArrayList<Question> {
        val questions = ArrayList<Question>()

        questions.add(
            Question(
                1,
                "Қазақстанның астанасы қай қала?",
                "Алматы",
                "Шымкент",
                "Астана",
                "Орал",
                3
            )
        )

        questions.add(
            Question(
                2,
                "Kotlin тілін кім әзірлеген?",
                "JetBrains",
                "Google",
                "Microsoft",
                "Oracle",
                1
            )
        )

        questions.add(
            Question(
                3,
                "Android қосымшаларының кеңейтімі қандай?",
                ".exe",
                ".apk",
                ".java",
                ".html",
                2
            )
        )

        return questions
    }
}
